<!DOCTYPE html>
<!-- html tag starts -->
<html lang="en">
<!-- head meta tag starts -->
<head>
	<title><?php echo get_bloginfo( 'name' ); ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1, user-scalable=0">

	<?php if ( get_theme_mod( 'favicon','' ) != '') { ?>
	<link rel="shortcut icon" href="<?php echo stripslashes( get_theme_mod( 'favicon' ) ); ?>" />
	<?php } ?>

	<?php wp_head(); ?>
	 <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/assets/css/bootstrap.min.css">
	 <script src="<?php bloginfo('template_directory'); ?>/assets/js/jquery.min.js"></script>
	 <script src="<?php bloginfo('template_directory'); ?>/assets/js/bootstrap.min.js"></script>
	 <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700" rel="stylesheet">
	 <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet"> 
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/style.css">
</head>
<!-- head meta tag ends -->

<body  <?php body_class(); ?>>
 <?php
$logo = get_theme_mod('logo'); 
 ?>
<!-- header type starts -->
<header>
<nav class="navbar navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
	   <a class="navbar-brand" href=" <?php { echo site_url(); } ?> ">
		  <img src="<?php echo $logo; ?>" alt="logo" width="65px">
	   </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
		<?php 
		
		$defaults = array(
		'menu' => 'Main Menu',
		'menu_class'      => 'nav navbar-nav navbar-right',
		'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
		);

		wp_nav_menu( $defaults );?>
		 
    </div>
  </div>
</nav>
<?php if ( is_front_page() && is_home() ) { ?>
<div class="container main">
<div class="row">
  
  <div class="col-sm-6 mt-9">
    <h1>Have your <br>best call</h1>
	<p>Fast, easy & unlimited conferece call services</p>
	<div class="row pt-9">
		<a href="#" class="previous">Try it Free</a>
		<a href="#" class="next borderdark">Get a Demo  </a>
 	 </div>
  </div>
  <div class="col-sm-6">
     <img src="<?php bloginfo('template_directory'); ?>/assets/images/hero-image.jpg" width=100% border=0>
  </div>
  
</div>
</div>
<?php } ?>
</header>
