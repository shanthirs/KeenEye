 
<footer>
	<div class="container">    

		<div class="row pb-80">
			<div class="col-sm-3">
				<a href="<?php echo get_theme_mod('footer_logo_url');?>"><img src="<?php echo get_theme_mod('footer_logo');?>" class="img-responsive" alt="Image"></a>
				<p class="text-left pb-30 pfoot"><?php echo get_theme_mod('footer_title');?></p>
			</div>

			<div class="col-sm-2"> 
				 <?php dynamic_sidebar( 'footer-section-one' ); ?>
			</div>
			
			<div class="col-sm-2"> 
				<?php dynamic_sidebar( 'footer-section-two' ); ?>
			</div> 
			
			<div class="col-sm-2"> 
				<?php dynamic_sidebar( 'footer-section-three' ); ?>
			</div>     
			
			<div class="col-sm-2"> 
				<span class="tit">Contact Us</span>
				
				<ul class="list-group ">
				<li class="list-group-item"><a href="mailto:<?php echo get_theme_mod('contact_email');?>" style="color:rgba(0, 0, 0, 0.84)"><?php echo get_theme_mod('contact_email');?></a></li>
				<li class="list-group-item"><a href="tel:<?php echo get_theme_mod('contact_phone');?>" style="color:rgba(0, 0, 0, 0.84)"><?php echo get_theme_mod('contact_phone');?></a></li>
				<li class="list-group-item"><?php echo get_theme_mod('contact_address');?></li> 
				</ul>
			</div> 
		</div>
		
		<div class="row">
			<div class="col-sm-12">
				<p class="text-left pb-30 pfoot copyright"><?php echo get_theme_mod('copyright_text');?></p>
			</div>
		
		</div>
		
	</div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
