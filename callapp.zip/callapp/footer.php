 
<footer>
	<div class="container">    

		<div class="row pb-80">
			<div class="col-sm-3">
				<img src="<?php if (get_theme_mod('footer_logo')!='') echo get_theme_mod('footer_logo'); else echo bloginfo('template_directory').'/assets/images/callapp_foot.png';?>" class="img-responsive" alt="Image">
				<p class="text-left pb-30 pfoot"><?php if (get_theme_mod('footer_title')!='') echo get_theme_mod('footer_title'); else echo 'The last team chat you<br >will ever need'; ?></p>
			</div>

			<div class="col-sm-2"> 
				<?php 
				if (  dynamic_sidebar( 'footer-section-one' )!='1' ) { ?>
				 <?php dynamic_sidebar( 'footer-section-one' ); ?>
				<? } else {?>
				 <span class="tit">Help</span>
				   <ul class="list-group ">
					<li class="list-group-item">Support</li>
					<li class="list-group-item">Knowledge Base</li>
					<li class="list-group-item">Tutorials</li>
				  </ul>
				<?php }?>
			</div>
			
			<div class="col-sm-2"> 
				<?php 
				 	if (  dynamic_sidebar( 'footer-section-two' )!='1' ) { ?>
				 <?php dynamic_sidebar( 'footer-section-two' ); ?>
				<? } else {?>
				 <span class="tit">Features</span>
				   <ul class="list-group">
					<li class="list-group-item">Screen Sharing</li>
					<li class="list-group-item">iOS & Android Apps</li>
					<li class="list-group-item">File Sharing</li>
					<li class="list-group-item">User Management</li>
				  </ul>
				<?php }?>
			</div> 
			
			<div class="col-sm-2"> 
				<?php 
				 
				if (  dynamic_sidebar( 'footer-section-three' )!='1') { ?>
				 <?php dynamic_sidebar( 'footer-section-three' ); ?>
				<? } else {?>
				<span class="tit">Company</span>
				   <ul class="list-group ">
					<li class="list-group-item">About Us</li>
					<li class="list-group-item">Careers</li>
					<li class="list-group-item">Contact Us</li> 
				  </ul>
				<?php }?>
			</div>     
			
			<div class="col-sm-2"> 
				<span class="tit">Contact Us</span>
				
				<ul class="list-group ">
				<li class="list-group-item"><a href="mailto:<?php if (get_theme_mod('contact_email')!='') echo get_theme_mod('contact_email'); else echo 'info@chatapp.com';?>" style="color:rgba(0, 0, 0, 0.84)"><?php if (get_theme_mod('contact_email')!='') echo get_theme_mod('contact_email'); else echo 'info@chatapp.com';?></a></li>
				<li class="list-group-item"><a href="tel:<?php if (get_theme_mod('contact_phone')!='') echo get_theme_mod('contact_phone'); else echo '1-800-200-300';?>" style="color:rgba(0, 0, 0, 0.84)"><?php if (get_theme_mod('contact_phone')!='') echo get_theme_mod('contact_phone'); else echo '1-800-200-300';?></a></li>
				<li class="list-group-item"><?php if (get_theme_mod('contact_address')!='') echo get_theme_mod('contact_address'); else echo '3500 Deer Creek Rd Palo Alto, CA';?></li> 
				</ul>
			</div> 
		</div>
		
		<div class="row">
			<div class="col-sm-12">
				<p class="text-left pb-30 pfoot copyright"><?php if (get_theme_mod('copyright_text')!='') echo get_theme_mod('copyright_text'); else echo '© Copyright Chatpp Inc.'; ?></p>
			</div>
		
		</div>
		
	</div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
