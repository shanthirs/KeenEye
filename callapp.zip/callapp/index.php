<?php get_header();?>
<?php if ( is_front_page() || is_home() ) { ?>
<section class="main-content">

	<div class="container text-center section2">  
		<div class="row">

		<div class="col-sm-12">
			<h3>Instant Conference Calls</h3>
		</div>
		
		<div class="col-sm-12 inner-text text-center">

			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pellentesque vulputate sapien id accumsan. Phasellus luctus nisi felis, in placerat urna convallis vitae. In egestas lectus scelerisque ipsum feugiat, vitae efficitur lectus eleifend. Suspendisse quis arcu in erat pulvinar tempor. Donec sed tempor eros, nec venenatis felis. Nam pellentesque, tortor.</p>

		</div>
		
		<div class="col-sm-12 mt-30">
			<img src="<?php bloginfo('template_directory'); ?>/assets/images/chat.png" class="img-responsive" style="width:100%" alt="Image">
		</div>
		
		</div>
	</div>

</section>

<section class="row3-content">

	<div class="container section3">
		<div class="row" >
		  
		  <div class="col-sm-12">
			  <div class="col-sm-6 pr-30">
				<img src="<?php bloginfo('template_directory'); ?>/assets/images/client.png" width=100% border=0 >
			  </div>
			  
			  <div class="col-sm-6">
			  
				<h1>Perfect Solution <br>for Small Businesses</h1>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
				
				<div class="row mt-30">
					<a href="#" class="next activebtn">Try it Free</a>
					<a href="#" class="previous transparentbg">Get a Demo  </a> 
				 </div>
				 
				 <div class="row">
				 <hr style="width: 200px;float: left;clear: both;border:1px solid rgba(36, 42, 45, 0.54);margin-top: 10px;margin-left: 20px;">
				 </div>
				 
				 <div class="row">
					 <div class="col-sm-3">
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
					 </div>
					 <div class="col-sm-8">
						<p><b>9,876 businesses</b> use ChatApp and they rate it as <b>5-stars</b></p>
					 </div>
				 </div>
				 
			  </div>  
		  </div>
		  
		</div>
	</div>

</section>
<?php } else { ?>

<section class="main-content">

    <div class="container">

      <?php if (have_posts()) : while(have_posts()) : the_post();?>


          <?php the_content();?>

      <?php endwhile; endif;?>

    </div>

  </section>
  
<?php } ?>
<?php get_footer();?>
