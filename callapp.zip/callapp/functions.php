<?php
if(!defined('Callapp')) {
	define('Callapp', dirname(__FILE__));
}

require_once( Callapp . '/customizer.php' );

function callapp_setup() {
	if ( ! isset( $content_width ) )
		$content_width = 640; /* pixels */
 
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'callapp' ),
	) );
  

}
add_action( 'after_setup_theme', 'callapp_setup' );


add_filter( 'wp_nav_menu_items', 'add_loginout_link', 10, 2 );

function add_loginout_link( $items, $args ) {
 
if ($args->menu  == 'Main Menu') {
	$items .= '<li><button type="button" class="libtn">Try it Free</button></li>';
}
 
return $items;
}


function callapp_widget(){

register_sidebar( array(
    'name'          => esc_html__( 'Footer Section One', 'callapp' ),
    'id'            => 'footer-section-one',
    'description'   => esc_html__( 'Widgets added here would appear inside the second section of the footer', 'callapp' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget'  => '</aside>',
    'before_title'  => '<span class="tit">',
    'after_title'   => '</span>',
) );

register_sidebar( array(
    'name'          => esc_html__( 'Footer Section Two', 'callapp' ),
    'id'            => 'footer-section-two',
    'description'   => esc_html__( 'Widgets added here would appear inside the third section of the footer', 'callapp' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget'  => '</aside>',
    'before_title'  => '<span class="tit">',
    'after_title'   => '</span>',
) );


register_sidebar( array(
    'name'          => esc_html__( 'Footer Section Three', 'callapp' ),
    'id'            => 'footer-section-three',
    'description'   => esc_html__( 'Widgets added here would appear inside the four section of the footer', 'callapp' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget'  => '</aside>',
    'before_title'  => '<span class="tit">',
    'after_title'   => '</span>',
) );
}
add_action( 'widgets_init', 'callapp_widget' );